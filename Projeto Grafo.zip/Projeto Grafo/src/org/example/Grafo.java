package org.example;

import java.awt.Point;
import java.util.*;

public class Grafo {
    final Map<Integer, List<Aresta>> adjacencias;
    private final LinkedHashSet<Integer> vertices;

    public Grafo() {
        adjacencias = new HashMap<>();
        vertices = new LinkedHashSet<>();
    }


    public void inserirVertice(int id) {
        if (!adjacencias.containsKey(id)) {
            adjacencias.put(id, new ArrayList<>());
            vertices.add(id);
        }
    }

    public void inserirAresta(int origem, int destino, int peso) {
        adjacencias.computeIfAbsent(origem, k -> new ArrayList<>()).add(new Aresta(destino, peso));
        adjacencias.computeIfAbsent(destino, k -> new ArrayList<>()).add(new Aresta(origem, peso)); // Grafo não direcionado
    }

    public void removerVertice(int id) {
        adjacencias.values().forEach(list -> list.removeIf(aresta -> aresta.destino == id));
        adjacencias.remove(id);
        vertices.remove(id);
    }

    public void removerAresta(int origem, int destino) {
        adjacencias.getOrDefault(origem, new ArrayList<>()).removeIf(aresta -> aresta.destino == destino);
        adjacencias.getOrDefault(destino, new ArrayList<>()).removeIf(aresta -> aresta.destino == origem);
    }

    public int informarGrau(int id) {
        if (!adjacencias.containsKey(id)) {
            return -1; // Vértice não encontrado
        }
        return adjacencias.get(id).size();
    }

    public boolean verificarConexo() {
        if (adjacencias.isEmpty()) {
            return true;
        }

        Set<Integer> visitados = new HashSet<>();
        int inicio = adjacencias.keySet().iterator().next();
        buscaEmLargura(inicio, visitados);

        return visitados.size() == adjacencias.size();
    }

    private void buscaEmLargura(int vertice, Set<Integer> visitados) {
        Queue<Integer> fila = new LinkedList<>();
        fila.add(vertice);
        visitados.add(vertice);

        while (!fila.isEmpty()) {
            int v = fila.poll();
            for (Aresta aresta : adjacencias.getOrDefault(v, new ArrayList<>())) {
                if (visitados.add(aresta.destino)) {
                    fila.add(aresta.destino);
                }
            }
        }
    }

    public int[][] converterParaMatrizAdjacencia() {
        List<Integer> listaVertices = new ArrayList<>(vertices);
        int tamanho = listaVertices.size();
        int[][] matriz = new int[tamanho][tamanho];
        Map<Integer, Integer> indices = obterPosicoesVertices(listaVertices);

        for (Map.Entry<Integer, List<Aresta>> entry : adjacencias.entrySet()) {
            int origem = entry.getKey();
            int origemIndex = indices.get(origem);
            for (Aresta aresta : entry.getValue()) {
                int destinoIndex = indices.get(aresta.destino);
                matriz[origemIndex][destinoIndex] = aresta.peso;
            }
        }
        return matriz;
    }



    public Map<Integer, Integer> obterPosicoesVertices(List<Integer> listaVertices) {
        Map<Integer, Integer> indices = new HashMap<>();
        for (int i = 0; i < listaVertices.size(); i++) {
            indices.put(listaVertices.get(i), i);
        }
        return indices;
    }

    public Map<Integer, Point> gerarPosicoesVertices(int largura, int altura) {
        Map<Integer, Point> posicoes = new HashMap<>();
        List<Integer> listaVertices = new ArrayList<>(vertices);
        int tamanho = listaVertices.size();
        int raio = 200; // Raio do círculo de distribuição dos vértices

        // Distribui os vértices ao longo de um círculo
        for (int i = 0; i < tamanho; i++) {
            double angulo = 2 * Math.PI * i / tamanho;
            int x = (int) (largura / 2 + raio * Math.cos(angulo));
            int y = (int) (altura / 2 + raio * Math.sin(angulo));
            posicoes.put(listaVertices.get(i), new Point(x, y));
        }
        return posicoes;
    }

    public void exibirMatrizAdjacencia() {
        int[][] matriz = converterParaMatrizAdjacencia();
        List<Integer> listaVertices = new ArrayList<>(vertices);
        int tamanho = matriz.length;

        System.out.println("Matriz de Adjacência:");

        // Cabeçalhos das colunas
        System.out.print("    ");
        for (Integer vertice : listaVertices) {
            System.out.print(String.format("%4d", vertice));
        }
        System.out.println();

        // Conteúdo da matriz
        for (int i = 0; i < tamanho; i++) {
            // Cabeçalhos das linhas
            System.out.print(String.format("%2d: ", listaVertices.get(i)));
            for (int j = 0; j < tamanho; j++) {
                System.out.print(String.format("%4d", matriz[i][j]));
            }
            System.out.println();
        }
    }

    public void buscaEmLargura(int inicio) {
        Set<Integer> visitados = new HashSet<>();
        buscaEmLargura(inicio, visitados);
        System.out.println(visitados);
    }

    public void buscaEmProfundidade(int inicio) {
        Set<Integer> visitados = new HashSet<>();
        buscaEmProfundidade(inicio, visitados);
        System.out.println(visitados);
    }

    private void buscaEmProfundidade(int vertice, Set<Integer> visitados) {
        Stack<Integer> pilha = new Stack<>();
        pilha.add(vertice);
        while (!pilha.isEmpty()) {
            int v = pilha.pop();
            if (visitados.add(v)) {
                for (Aresta aresta : adjacencias.getOrDefault(v, new ArrayList<>())) {
                    pilha.add(aresta.destino);
                }
            }
        }
    }

    public Map<Integer, Integer> caminhoMinimoDijkstra(int origem) {
        Map<Integer, Integer> distancias = new HashMap<>();
        PriorityQueue<Distancia> pq = new PriorityQueue<>(Comparator.comparingInt(d -> d.distancia));

        for (Integer vertice : adjacencias.keySet()) {
            distancias.put(vertice, Integer.MAX_VALUE);
        }
        distancias.put(origem, 0);
        pq.add(new Distancia(origem, 0));

        while (!pq.isEmpty()) {
            Distancia atual = pq.poll();
            int u = atual.vertice;
            int distanciaU = atual.distancia;

            if (distanciaU > distancias.get(u)) {
                continue;
            }

            for (Aresta aresta : adjacencias.getOrDefault(u, new ArrayList<>())) {
                int v = aresta.destino;
                int novaDistancia = distanciaU + aresta.peso;
                if (novaDistancia < distancias.get(v)) {
                    distancias.put(v, novaDistancia);
                    pq.add(new Distancia(v, novaDistancia));
                }
            }
        }
        return distancias;
    }

    public Set<Aresta> arvoreGeradoraMinimaPrim(int inicio) {
        Set<Aresta> arvore = new HashSet<>();
        PriorityQueue<Aresta> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a.peso));
        Set<Integer> visitados = new HashSet<>();

        visitados.add(inicio);
        for (Aresta aresta : adjacencias.getOrDefault(inicio, new ArrayList<>())) {
            pq.add(aresta);
        }

        while (!pq.isEmpty()) {
            Aresta aresta = pq.poll();
            if (visitados.contains(aresta.destino)) {
                continue;
            }

            arvore.add(aresta);
            visitados.add(aresta.destino);

            for (Aresta novaAresta : adjacencias.getOrDefault(aresta.destino, new ArrayList<>())) {
                if (!visitados.contains(novaAresta.destino)) {
                    pq.add(novaAresta);
                }
            }
        }

        return arvore;
    }

    private static class Distancia {
        int vertice;
        int distancia;

        Distancia(int vertice, int distancia) {
            this.vertice = vertice;
            this.distancia = distancia;
        }
    }

    public static class Aresta {
        int destino;
        int peso;

        public Aresta(int destino, int peso) {
            this.destino = destino;
            this.peso = peso;
        }
    }

}

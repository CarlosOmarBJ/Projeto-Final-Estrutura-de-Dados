package org.example;

public class Aresta {
    int destino;
    int peso;

    public Aresta(int destino, int peso) {
        this.destino = destino;
        this.peso = peso;
    }

    public String toString() {
        return "Destino: " + destino + ", Peso: " + peso;
    }
}

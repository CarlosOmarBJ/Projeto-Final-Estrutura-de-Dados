package org.example;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

public class GrafoPanel extends JPanel {
    private final Map<Integer, List<Grafo.Aresta>> adjacencias;
    private final Map<Integer, Point> posicoesVertices;

    public GrafoPanel(Map<Integer, List<Grafo.Aresta>> adjacencias, Map<Integer, Point> posicoesVertices) {
        this.adjacencias = adjacencias;
        this.posicoesVertices = posicoesVertices;
        setPreferredSize(new Dimension(800, 600));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        desenharGrafo(g);
    }

    private void desenharGrafo(Graphics g) {
        // Define a cor verde fosco para os vértices
        Color corVertice = new Color(255, 165, 0); // Verde floresta

        // Desenha os vértices
        for (Integer vertice : posicoesVertices.keySet()) {
            Point ponto = posicoesVertices.get(vertice);
            g.setColor(corVertice);
            g.fillOval(ponto.x - 10, ponto.y - 10, 20, 20);
            g.setColor(Color.BLACK);
            g.drawString(vertice.toString(), ponto.x - 5, ponto.y + 5);
        }

        // Desenha as arestas
        for (Map.Entry<Integer, List<Grafo.Aresta>> entry : adjacencias.entrySet()) {
            Integer origem = entry.getKey();
            Point pontoOrigem = posicoesVertices.get(origem);
            for (Grafo.Aresta aresta : entry.getValue()) {
                Point pontoDestino = posicoesVertices.get(aresta.destino);
                g.setColor(Color.BLACK);
                g.drawLine(pontoOrigem.x, pontoOrigem.y, pontoDestino.x, pontoDestino.y);
                int meioX = (pontoOrigem.x + pontoDestino.x) / 2;
                int meioY = (pontoOrigem.y + pontoDestino.y) / 2;
                g.drawString(String.valueOf(aresta.peso), meioX, meioY);
            }
        }
    }
}
